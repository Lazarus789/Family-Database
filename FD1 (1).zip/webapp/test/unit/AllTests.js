sap.ui.define([
	"com/FamilyDetails/test/unit/controller/View1.controller"
], function () {
	"use strict";
});