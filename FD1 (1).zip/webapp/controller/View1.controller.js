sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter"
], function (Controller, Filter) {
	"use strict";
	var jModel = new sap.ui.model.json.JSONModel();
	return Controller.extend("com.FamilyDetails.controller.View1", {
		onInit: function () {

		},
		onClick: function () {
			var BusyDialog = new sap.m.BusyDialog();
			BusyDialog.open();
			var sUrl1 = "/sap/opu/odata/sap/ZFAM3_DETAILS_SRV/";
			var input_pernr = this.getView().byId("enter").getValue();
			var aFilter = [];
			aFilter.push(new Filter("Pernr", "EQ", input_pernr));
			var oModel1 = new sap.ui.model.odata.ODataModel(sUrl1, true);
			sap.ui.getCore().setModel(oModel1, "Model1");
			this.oList = this.getView().byId("table0");

			var that = this;
			this.getView().byId("table0").setVisible(true);
			sap.ui.getCore().getModel("Model1").read("/FAMTAB3Set", {
				filters: aFilter,
				success: function (oData, response) {
					var oResults = oData.results;
					
					jModel.setData(oResults);

					sap.ui.getCore().setModel(jModel, "myModel");
					that.oList.setModel(jModel, "myModel");
					BusyDialog.close();
				}
			});

		}
	});
});